@extends('layouts.app')

@section('content')
    <div class="bg-[#000312] text-white h-screen w-screen flex justify-center items-center">
        <div class="flex flex-col items-center">
            <!-- Univeristy' Logo -->
            <div class="text-center">
                <img src="/images/svg/logo.svg" alt="" class="mx-auto">
                <h1 class="font-bold text-2xl my-4">Your Request Is Submitted</h1>
            </div>
            <div class="mt-10 w-1/2 p-8 rounded-xl font-bold text-black bg-[#52B788]">
                <p>
                    Dear Manssif, We received your request, we are now take it into consideration
                    you will receive an email message as soon as we finish processing your request
                    take care !!
                </p>
            </div>
        </div>
    </div>
@endsection
