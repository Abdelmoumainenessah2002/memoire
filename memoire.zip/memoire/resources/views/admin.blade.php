@extends('layouts.app')

@section('content')
    <div class="bg-[#000312] h-screen w-screen flex justify-center items-center">
        <div class="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="w-full shadow overflow-hidden sm:rounded-lg rounded-t-lg">
                <table class="w-full divide-y">
                    <thead class="bg-[#D8F3DC] text-black">
                        <tr>
                            <th scope="col" class="px-6 py-4 text-left text-xs font-medium uppercase tracking-wider">
                                Request ID
                            </th>
                            <th scope="col" class="px-6 py-4 text-left text-xs font-medium uppercase tracking-wider">
                                User Email
                            </th>
                            <th scope="col" class="px-6 py-4 text-left text-xs font-medium uppercase tracking-wider">
                                State
                            </th>
                            <th scope="col" class="px-6 py-4 text-left text-xs font-medium uppercase tracking-wider">
                                Address
                            </th>
                            <th scope="col" class="px-6 py-4 text-left text-xs font-medium uppercase tracking-wider">
                                ZipCode
                            </th>
                            <th scope="col" class="px-6 py-4 text-left text-xs font-medium uppercase tracking-wider">
                                Residence Document URL
                            </th>
                            <th scope="col" class="px-6 py-4 text-left text-xs font-medium uppercase tracking-wider">
                                Delete
                            </th>
                        </tr>
                    </thead>
                    <tbody class="divide-y text-white">
                        @foreach($requests as $request)
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-medium">{{ $request->id }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-medium">{{ $request->user->email }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-medium">{{ $request->state }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-medium">{{ $request->city . ", " . $request->address }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-medium">{{ $request->zipcode }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-medium text-center"><a target="_blank" href={{ $request->residence_document }}>click here</a></div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm font-medium text-center">
                                    <form method="POST" action="{{ route('deleteRequest', ['id' => $request->id]) }}">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit">Yes</button>
                                </form>
                            </div>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
