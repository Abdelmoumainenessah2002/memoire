@extends('layouts.app')

@section('content')
    <div class="bg-[#000312] text-white h-screen w-screen flex justify-center items-center">
        <div class="flex flex-col items-center">
            <!-- Univeristy' Logo -->
            <div class="text-center">
                <img src="/images/svg/logo.svg" alt="" class="mx-auto">
                <h1 class="font-bold text-2xl my-4">Register</h1>
            </div>

            <div>
                <form method="POST" action="{{ route('register') }}">
                    @csrf

                    <div class="my-4">
                        <div>
                            <input id="name" type="text" placeholder="Name"
                                class="w-full bg-[#D8F3DC] text-black placeholder:text-black font-semibold py-2 px-4 rounded-xl outline-none"
                                name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>

                            @error('name')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div>
                        <div>
                            <input id="email" type="email" placeholder="Email"
                                class="w-full bg-[#D8F3DC] text-black placeholder:text-black font-semibold py-2 px-4 rounded-xl outline-none"
                                name="email" value="{{ old('email') }}" required autocomplete="email">

                            @error('email')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="flex w-full gap-2 my-4">
                        <div>
                            <input id="password" type="password" placeholder="Password"
                                class="w-40 bg-[#D8F3DC] text-black placeholder:text-black font-semibold py-2 px-4 rounded-xl outline-none"
                                name="password" required autocomplete="new-password">

                            @error('password')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <div>
                            <input id="password-confirm" type="password" placeholder="Re-Password"
                                class="w-40 bg-[#D8F3DC] text-black placeholder:text-black font-semibold py-2 px-4 rounded-xl outline-none"
                                name="password_confirmation" required autocomplete="new-password">
                        </div>
                    </div>

                    <div class="flex items-center">
                        <button type="submit" class="mx-auto bg-[#00292D] px-6 py-2 rounded-xl font-bold">
                            {{ __('Register') }}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
