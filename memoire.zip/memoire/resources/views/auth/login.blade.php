@extends('layouts.app')

@section('content')
    <div class="bg-[#000312] text-white h-screen w-screen flex justify-center items-center">
        <div class="flex flex-col items-center">
            <!-- Univeristy' Logo -->
            <div class="text-center">
                <img src="/images/svg/logo.svg" alt="" class="mx-auto">
                <h1 class="font-bold text-2xl my-4">Login</h1>
            </div>

            <div>
                <form method="POST" action="{{ route('login') }}">
                    @csrf

                    <!-- Email Field -->
                    <div class="my-4">
                        <div>
                            <input id="email" type="email" placeholder="Email"
                                class="bg-[#D8F3DC] text-black placeholder:text-black font-semibold py-2 px-4 rounded-xl outline-none"
                                name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>

                            @error('email')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <!-- Password Field -->
                    <div class="my-4">
                        <div>
                            <input id="password" type="password" placeholder="Password"
                                class="bg-[#D8F3DC] text-black placeholder:text-black font-semibold py-2 px-4 rounded-xl outline-none"
                                name="password" required autocomplete="current-password">

                            @error('password')
                                <span role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <!-- Remember Me Checkbox -->
                    <div>
                        <input type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>

                        <label for="remember">
                            {{ __('Remember Me') }}
                        </label>
                    </div>

                    <!-- Login Button -->
                    <div class="my-4 flex flex-col">
                        <button type="submit" class="mx-auto bg-[#00292D] px-6 py-2 rounded-xl font-bold">
                            {{ __('Login') }}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
