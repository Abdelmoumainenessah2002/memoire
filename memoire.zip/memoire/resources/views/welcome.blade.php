@extends('layouts.app')

@section('content')
    <div class="space-y-52">
        <div class="relative flex items-center justify-center w-full h-[80vh] bg-cover bg-center bg-no-repeat bg-[url('../../public/images/png/bg.png')]">
            <div class="font-bold text-center text-white space-y-5">
                <h1 class="uppercase text-6xl drop-shadow-md">it's your time</h1>
                <p class="text-2xl">book, and get your keys the same day</p>
                <a href="/register" role="button"
                    class="block w-fit mx-auto capitalize bg-[#00292D] px-6 py-2 rounded-xl text-xl">get start</a>
            </div>
            <!--Bar-->
            <img src="/images/svg/bar.svg" alt="bar" class="absolute -bottom-36" />
        </div>
        <!-- About -->
        <div id="about" class="text-center space-y-10 w-[55%] mx-auto">
            <h2 class="capitalize text-[#74C69D] font-bold text-4xl">about</h2>
            <div class="text-white text-lg leading-8">
                <p>We are a university branch of the Ministry of University Services, our mission is to receive students who
                    are away from the university and provide all services and life requirements such as eating, drinking,
                    sleeping, protection, sports, etc.</p>
                <p>Our organization ensures that these services are provided over 24/7, With us, eat the best cuisine and
                    get a suitable environment for your study, What are you waiting for register with us and get our
                    services immediately</p>
            </div>
            <div class="flex items-center justify-between">
                <div class="w-[25%] h-[3px] bg-[#74C69D] rounded-xl"></div>
                <div class="w-[65%] h-[3px] bg-[#74C69D] rounded-xl"></div>
            </div>
        </div>
        <!-- Images -->
        <div class="w-[55%] mx-auto flex items-center justify-between flex-wrap">
            <img src="/images/png/1.png" alt="" class="w-[20rem]">
            <img src="/images/png/2.png" alt="" class="w-[20rem]">
        </div>
        <!-- Contact -->
        <div class="w-[55%] mx-auto text-center space-y-10 pb-20">
            <h2 class="capitalize text-[#74C69D] font-bold text-4xl">contact</h2>

            <form id="contact" class="space-y-5">
                <div class="flex items-center justify-between">
                    <input id="name" type="text" placeholder="Name"
                        class="w-[40%] bg-[#D8F3DC] text-black placeholder:text-black font-semibold py-2 px-4 rounded-xl outline-none"
                        name="name" value="{{ old('name') }}" required autocomplete="name">
                    <input id="email" type="email" placeholder="Email"
                        class="w-[50%] bg-[#D8F3DC] text-black placeholder:text-black font-semibold py-2 px-4 rounded-xl outline-none"
                        name="email" value="{{ old('email') }}" required autocomplete="email">
                </div>
                <textarea id="message" type="text" placeholder="Message"
                class="w-full h-40 bg-[#D8F3DC] text-black placeholder:text-black font-semibold py-2 px-4 rounded-xl outline-none"
                ></textarea>
                <button type="submit" class="mx-auto bg-[#00292D] text-white px-6 py-2 rounded-xl font-bold">
                    {{ __('Contact') }}
                </button>
            </form>
        </div>
    </div>
@endsection
