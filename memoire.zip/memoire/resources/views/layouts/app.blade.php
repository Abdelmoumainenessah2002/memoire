<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Cité Unniversitaire') }}</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <!-- Scripts -->
    @viteReactRefresh
    @vite(['resources/sass/app.scss', 'resources/js/app.js'])
</head>

<body>
    <!-- NavBar -->
    <div class="z-50 fixed top-5 w-full">
        <nav
            class="container bg-[#000312] text-white shadow-sm flex items-center justify-between w-1/2 rounded-xl mx-auto p-4">
            <ul class="flex font-bold">
                <li class="mx-4"><a href="/">Home</a></li>
                <li class="mx-4"><a href="/#about">About</a></li>
                <li class="mx-4"><a href="/#contact">Contact</a></li>
            </ul>
            <div>
                <!-- Right Side Of Navbar -->
                <ul class="flex">
                    <!-- Authentication Links -->
                    @guest
                        @if (Route::has('login'))
                            <li class="bg-[#00292D] font-bold px-5 py-2 rounded-xl">
                                <a href="{{ route('login') }}">{{ __('Login') }}</a>
                            </li>
                        @endif
                    @else
                        <li>
                            <a href="#" role="button"
                                aria-haspopup="true" aria-expanded="false" v-pre>
                                {{ Str::length((Auth::user()->name)) > 15 ? Str::substr(Auth::user()->name, 0, 15) . "..." : Auth::user()->name }}
                            </a>

                            <div>
                                <a href="{{ route('logout') }}"
                                    onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                                    {{ __('Logout') }}
                                </a>

                                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                    @csrf
                                </form>
                            </div>
                        </li>
                    @endguest
                </ul>
            </div>
        </nav>
    </div>
    <main>
        @yield('content')
    </main>
</body>

</html>
