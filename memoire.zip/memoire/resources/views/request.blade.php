@extends('layouts.app')

@section('content')
    <div class="bg-[#000312] text-white h-screen w-screen flex justify-center items-center">
        <div class="flex flex-col items-center">
            <!-- Univeristy' Logo -->
            <div class="text-center">
                <img src="/images/svg/logo.svg" alt="" class="mx-auto">
                <h1 class="font-bold text-2xl my-4">Request A Room</h1>
            </div>
            <div>
                <form method="POST" action="{{ route('createRequest') }}">
                    @csrf

                    <div class="my-4">
                        <div>
                            <input id="city" type="text" placeholder="City"
                                class="w-full bg-[#D8F3DC] text-black placeholder:text-black font-semibold py-2 px-4 rounded-xl outline-none"
                                name="city" value="{{ old('city') }}" required autocomplete="city" autofocus>

                            @error('city')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="flex w-full gap-2 my-4">
                        <div>
                            <input id="state" type="text" placeholder="State"
                                class="w-40 bg-[#D8F3DC] text-black placeholder:text-black font-semibold py-2 px-4 rounded-xl outline-none"
                                name="state" required autocomplete="state">

                            @error('state')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>

                        <div>
                            <input id="zipcode" type="text" placeholder="Zip Code"
                                class="w-40 bg-[#D8F3DC] text-black placeholder:text-black font-semibold py-2 px-4 rounded-xl outline-none"
                                name="zipcode" required autocomplete="zipcode">

                            @error('zipcode')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="my-4">
                        <div>
                            <input id="address" type="text" placeholder="Address"
                                class="w-full bg-[#D8F3DC] text-black placeholder:text-black font-semibold py-2 px-4 rounded-xl outline-none"
                                name="address" value="{{ old('address') }}" required autocomplete="address" autofocus>

                            @error('address')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="my-4">
                        <div>
                            <input id="residence_document" type="text" placeholder="Residence Document"
                                class="w-full bg-[#D8F3DC] text-black placeholder:text-black font-semibold py-2 px-4 rounded-xl outline-none"
                                name="residence_document" value="{{ old('residence_document') }}" required autocomplete="residence_document" autofocus>

                            @error('residence_document')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                    </div>

                    <div class="flex items-center">
                        <button type="submit" class="mx-auto bg-[#00292D] px-6 py-2 rounded-xl font-bold">
                            {{ __('Request') }}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
