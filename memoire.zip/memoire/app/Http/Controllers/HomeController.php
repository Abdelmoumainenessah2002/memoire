<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;
use App\Models\Request as RequestModel;


class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request)
    {
        // if the user is not the admin we don't need to render the page
        // we must redirect it to the home page.
        $user = Auth::user();
        if ($user->is_admin){
            // fetch all requests in the database with their users detials.
            $requests = RequestModel::with('user')->get();
            // pass them to the admin page.
            return view('admin', compact('requests'));
        }
        if(count($user->requests) == 0) return view('request');
        return view('home');
    }

    public function createRequest(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'state' => 'required|string',
            'city' => 'required|string',
            'zipcode' => 'required|string',
            'address' => 'required|string',
            'residence_document' => 'required|string',
        ]);
        // check the request body to make sure thay all the request required value are there.
        if ($validator->fails()) {
            return Redirect::back()->withErrors($validator)->withInput();
        }
        $requestData = $validator->validated();
        // get the current user object
        $user = auth()->user();
        // call the createRequest function to create the request for the current user.
        $request = $user->createRequest($requestData);
        return redirect('/home');
    }


    public function deleteRequest(Request $request, $id)
    {
        $request = RequestModel::findOrFail($id);
        $request->delete();
        // Optionally, you can add a success flash message or perform other actions
        return redirect()->back();
    }

}
